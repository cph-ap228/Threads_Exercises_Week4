package exercises.day2;


public class E1 {

}
