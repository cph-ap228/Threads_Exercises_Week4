package day1.fib;

public interface FibonacciObserver {
    void dataReady(long tal);
}
